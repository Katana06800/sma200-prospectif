from decimal import Decimal
from execution import PAIRS
from schedule import limits, window

DAY = 86400000

def check_closes(day, rows):
    midnight = limits(day)[0] - 900000
    expected = [
        midnight-i*DAY for i in range(200,0,-1)
    ]

    if not isinstance(rows, dict) or set(rows) != set(PAIRS):
        raise ValueError("Paires invalides")

    result = {}

    for p in PAIRS:
        data = rows[p]

        if not isinstance(data, list) or len(data) != 200:
            raise ValueError("Serie incomplete")

        if any(not isinstance(c, list) or len(c) != 9 or
               not all(isinstance(x, str) for x in c) or c[8] != "1"
               for c in data):
            raise ValueError("Bougie non validee")

        if [int(c[0]) for c in data] != expected:
            raise ValueError("Dates incorrectes")

        values = []
        for c in data:
            o, h, l, close, *volumes = map(Decimal, c[1:8])
            if not (all(v.is_finite() for v in (o,h,l,close,*volumes))
                    and 0 < l <= min(o, close)
                    and max(o, close) <= h
                    and all(v >= 0 for v in volumes)):
                raise ValueError("OHLCV invalide")
            values.append(close)

        result[p] = values

    return result

def check_quotes(day, clock, decision, final, quotes):
    if set(quotes) != set(PAIRS):
        raise ValueError("Paires invalides")

    for instant in (decision, final):
        if window(day, *clock.bounds(instant)) != "OPEN":
            raise ValueError("Fenetre fermee")

    for p in PAIRS:
        bid, ask, ts, received = quotes[p]

        if not decision <= received <= final:
            raise ValueError("Chronologie invalide")

        if not clock.accepts(ts, decision, received):
            raise ValueError("Cotation invalide")

        if not clock.accepts(ts, decision, final):
            raise ValueError("Cotation perimee")

    return quotes
