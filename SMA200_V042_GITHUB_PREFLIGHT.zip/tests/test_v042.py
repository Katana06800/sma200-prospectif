import errno
import os
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch, Mock
from state import initialize, load, publish_database

class NativeRenameTests(unittest.TestCase):
    def test_no_hardlink_required(self):
        with TemporaryDirectory() as tmp, patch('state.os.link', side_effect=PermissionError('hardlink forbidden'), create=True):
            dest = Path(tmp)/'db'
            initialize(dest, {'cash':'1000'})
            self.assertEqual(load(dest), (0, {'cash':'1000'}))
    def test_concurrent_initializers_only_one_wins(self):
        with TemporaryDirectory() as tmp:
            dest = Path(tmp)/'db'
            def attempt(i):
                try:
                    initialize(dest, {'id':i})
                    return i
                except FileExistsError:
                    return None
            with ThreadPoolExecutor(max_workers=8) as ex:
                winners = [i for i in ex.map(attempt, range(8)) if i is not None]
            self.assertEqual(len(winners), 1)
            self.assertEqual(load(dest), (0, {'id':winners[0]}))
    def test_dangling_symlink_not_followed(self):
        with TemporaryDirectory() as tmp:
            dest = Path(tmp)/'db'; target = Path(tmp)/'missing'
            dest.symlink_to(target)
            with self.assertRaises(FileExistsError): initialize(dest, {})
            self.assertTrue(dest.is_symlink()); self.assertFalse(target.exists())
    def test_unsupported_rename_fails_closed(self):
        with TemporaryDirectory() as tmp:
            dest = Path(tmp)/'db'
            with patch('state.ctypes.CDLL', return_value=object()):
                with self.assertRaisesRegex(OSError, 'renameat2'): initialize(dest,{})
            self.assertFalse(dest.exists())
    def test_permission_error_fails_closed(self):
        with TemporaryDirectory() as tmp:
            dest = Path(tmp)/'db'
            libc = Mock(); libc.renameat2.return_value = -1
            with patch('state.ctypes.CDLL', return_value=libc), patch('state.ctypes.get_errno', return_value=errno.EPERM):
                with self.assertRaises(PermissionError): initialize(dest,{})
            self.assertFalse(dest.exists())
