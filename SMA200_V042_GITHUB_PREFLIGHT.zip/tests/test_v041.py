import os
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from state import initialize, load, publish_database

class AndroidFallbackTests(unittest.TestCase):
    def test_fallback_initialization(self):
        with TemporaryDirectory() as tmp:
            dest = Path(tmp)/'test.db'
            with patch('state.os.link', None, create=True):
                initialize(dest, {'cash':'1000'})
            self.assertEqual(load(dest), (0, {'cash':'1000'}))

    def test_fallback_never_overwrites_file_or_directory(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root/'source'; source.write_text('new')
            dest = root/'dest'; dest.write_text('old')
            directory = root/'directory'; directory.mkdir()
            with patch('state.os.link', None, create=True):
                for target in (dest, directory):
                    with self.assertRaises(FileExistsError):
                        publish_database(source, target)
            self.assertEqual(dest.read_text(), 'old')
            self.assertEqual(list(directory.iterdir()), [])

    def test_fallback_failure_leaves_no_published_database(self):
        with TemporaryDirectory() as tmp:
            dest = Path(tmp)/'test.db'
            with patch('state.os.link', None, create=True), patch('state.ctypes.CDLL', side_effect=FileNotFoundError('libc')):
                with self.assertRaises(FileNotFoundError):
                    initialize(dest, {'cash':'1000'})
            self.assertFalse(dest.exists())
