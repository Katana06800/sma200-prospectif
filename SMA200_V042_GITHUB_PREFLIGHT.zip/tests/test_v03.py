import io
import json
import os
import subprocess
import sys
import unittest
from contextlib import closing
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch, Mock
from prospective import init, tick, checkpoint, mark_expired
from state import connect, load, initialize
from guard import check_closes
from market import get, ticker, sync_clock, candles
from journal import history
from clock import Clock
import test_guard as g
from schedule import limits

class RegressionTests(unittest.TestCase):
    def setUp(self):
        tmp = TemporaryDirectory(); self.addCleanup(tmp.cleanup)
        self.db = Path(tmp.name)/'paper.db'
        protocol = Path(tmp.name)/'protocol.md'; protocol.write_text('test')
        init(self.db,g.DATE,protocol,clock_provider=lambda:Clock(g.START-1000000,0,100000000),now=lambda:200000000)
    def mutate(self, revision, column, key, value):
        assert column in ('state','event')
        with closing(connect(self.db)) as db, db:
            raw = db.execute(f'SELECT {column} FROM journal WHERE revision=?',(revision,)).fetchone()[0]
            data=json.loads(raw); data[key]=value
            db.execute(f'UPDATE journal SET {column}=? WHERE revision=?',(json.dumps(data),revision))
    def test_initial_capital_tamper(self):
        self.mutate(0,'state','cash','1000000')
        with self.assertRaisesRegex(ValueError,'initial'):checkpoint(self.db)
    def test_initial_positions_tamper(self):
        self.mutate(0,'state','positions',{g.B:'1',g.E:'0'})
        with self.assertRaisesRegex(ValueError,'initial'):checkpoint(self.db)
    def test_initial_signal_tamper(self):
        self.mutate(0,'state','signals',[True,False])
        with self.assertRaisesRegex(ValueError,'initial'):checkpoint(self.db)
    def test_missed_signal_tamper(self):
        mark_expired(self.db,g.DATE,clock_provider=lambda:Clock(limits(g.DATE)[1]+1000,0,100000000),now=lambda:200000000,fetch=lambda p,d:g.rows()[p])
        self.mutate(1,'event','signals',[True,False])
        with self.assertRaisesRegex(ValueError,'manquee'):checkpoint(self.db)
    def test_bad_initial_state_blocks_execution(self):
        self.mutate(0,'state','cash','1000000'); fetch=Mock()
        with self.assertRaisesRegex(ValueError,'initial'):
            tick(self.db,clock_provider=lambda:Clock(g.START+1000,0,100000000),now=lambda:200000000,fetch=fetch)
        fetch.assert_not_called(); self.assertEqual(load(self.db)[0],0)
    def test_invalid_ohlcv(self):
        for col,val in [(1,'-1'),(2,'99'),(3,'101'),(5,'-1'),(6,'NaN')]:
            with self.subTest(col=col,val=val):
                rows=g.rows();rows[g.B][-1][col]=val
                with self.assertRaises(ValueError):check_closes(g.DATE,rows)
    def test_malformed_api_envelope(self):
        for obj in [None, [], {'code':'0','data':None}, {'code':0,'data':[]}]:
            with self.subTest(obj=obj), patch('market.urlopen',return_value=io.BytesIO(json.dumps(obj).encode())):
                with self.assertRaises(ValueError):get('public/time')
    def test_malformed_clock(self):
        for rows in [[],[None],[{'ts':None}],[{'ts':'abc'}]]:
            with self.subTest(rows=rows),patch('market.get',return_value=rows):
                with self.assertRaises(ValueError):sync_clock()
    def test_malformed_ticker(self):
        with patch('market.get',return_value=[None]):
            with self.assertRaises(ValueError):ticker(g.B)
    def test_malformed_candle(self):
        with patch('market.get',side_effect=[[{'ts':str(g.START)}],[None]]):
            with self.assertRaises(ValueError):candles(g.B,g.DATE)
    def test_malformed_response_logged_no_trade(self):
        with patch('market.urlopen',return_value=io.BytesIO(b'null')):
            with self.assertRaises(ValueError):tick(self.db)
        self.assertEqual(load(self.db)[0],0); self.assertEqual(history(self.db)[0][3],'CLOCK_ERROR')
    def test_crash_before_atomic_publish(self):
        other=self.db.with_name('other.db')
        child='import os,sys,state; state.publish_database=lambda *a:os._exit(77); state.initialize(sys.argv[1],{"cash":"1000"})'
        result=subprocess.run([sys.executable,'-c',child,str(other)],timeout=10)
        self.assertEqual(result.returncode,77); self.assertFalse(other.exists())
        initialize(other,{'cash':'1000'});self.assertEqual(load(other),(0,{'cash':'1000'}))
        self.assertEqual(history(other),[])
    def test_crash_after_atomic_publish(self):
        other=self.db.with_name('after.db')
        child='import os,sys,state; orig=state.publish_database; state.publish_database=lambda *a:(orig(*a),os._exit(77)); state.initialize(sys.argv[1],{"cash":"1000"})'
        result=subprocess.run([sys.executable,'-c',child,str(other)],timeout=10)
        self.assertEqual(result.returncode,77);self.assertEqual(load(other),(0,{'cash':'1000'}));self.assertEqual(history(other),[])
