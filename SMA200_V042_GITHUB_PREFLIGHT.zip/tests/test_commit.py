import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from state import initialize, load, save

class CommitTests(unittest.TestCase):

    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name)/"test.db"
        initialize(self.path, {"cash":"1000"})

    def test_expired_before_commit(self):
        def reject():
            raise ValueError("Cotation expiree")

        with self.assertRaises(ValueError):
            save(self.path,0,"2000-01-01",
                 {"cash":"500"},{},
                 before_commit=reject)

        self.assertEqual(
            load(self.path),(0,{"cash":"1000"})
        )

    def test_valid_commit(self):
        calls = []

        save(self.path,0,"2000-01-01",
             {"cash":"500"},{},
             before_commit=lambda: calls.append(1))

        self.assertEqual(calls,[1])
        self.assertEqual(
            load(self.path),(1,{"cash":"500"})
        )
