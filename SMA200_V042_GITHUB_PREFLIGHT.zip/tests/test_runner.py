import unittest
import test_guard as g
from tempfile import TemporaryDirectory
from pathlib import Path
from clock import Clock
from state import initialize, load
from journal import prepare
from runner import guarded_day

class RunnerTests(unittest.TestCase):

    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name)/"test.db"

        initialize(self.path, {
            "cash":"1000",
            "positions":{g.B:"0",g.E:"0"},
            "signals":None,
            "last_day":None
        })
        prepare(self.path)

    def run_day(self, data, times, offset=1000):
        ticks = iter(times)
        return guarded_day(
            self.path, g.DATE, data,
            lambda: Clock(g.START+offset,0,100000000),
            lambda c,d: g.quotes(),
            lambda: next(ticks)
        )

    def active_rows(self):
        data = g.rows()
        data[g.B][-1][4] = "105"
        return data

    def test_valid_execution(self):
        event = self.run_day(
            self.active_rows(),
            [200000000,250000000,650000000,700000000]
        )
        self.assertEqual(len(event["trades"]),1)
        self.assertEqual(load(self.path)[0],1)

    def test_expired_quote_before_save(self):
        before = load(self.path)
        with self.assertRaises(ValueError):
            self.run_day(
                self.active_rows(),
                [200000000,250000000,650000000,6000000000]
            )
        self.assertEqual(load(self.path),before)

    def test_closed_window(self):
        before = load(self.path)
        with self.assertRaises(ValueError):
            self.run_day(
                self.active_rows(),
                [200000000],offset=-10000
            )
        self.assertEqual(load(self.path),before)

    def test_invalid_dates(self):
        data = self.active_rows()
        data[g.B][-1][0] = "0"
        before = load(self.path)

        with self.assertRaises(ValueError):
            self.run_day(data,[])

        self.assertEqual(load(self.path),before)
