import unittest
import test_engine as engine
from test_engine import closes, quotes, forbidden
from recovery import mark_missed
from main import process_day
from state import load

class RecoveryTests(unittest.TestCase):
    setUp = engine.EngineTests.setUp
    first = engine.EngineTests.first

    def test_missed_preserves_positions(self):
        self.first()
        before = load(self.path)[1]

        event = mark_missed(
            self.path, "2000-01-02", "2000-01-02")

        after = load(self.path)[1]

        for key in ("cash", "positions", "signals"):
            self.assertEqual(before[key], after[key])

        self.assertEqual(event["trades"], [])
        self.assertEqual(event["type"], "DECISION_MANQUEE")

    def test_resume_after_gap(self):
        self.first()

        mark_missed(self.path, "2000-01-02", "2000-01-03")
        mark_missed(self.path, "2000-01-03", "2000-01-03")

        event = process_day(
            self.path, "2000-01-04",
            closes(False,True), quotes)

        self.assertEqual(
            [t["side"] for t in event["trades"]],
            ["SELL","BUY"])

    def test_no_early_missed_day(self):
        self.first()
        before = load(self.path)

        with self.assertRaises(ValueError):
            mark_missed(
                self.path, "2000-01-02", "2000-01-01")

        self.assertEqual(load(self.path), before)

    def test_resume_unchanged_signal(self):
        self.first()
        mark_missed(
            self.path, "2000-01-02", "2000-01-02")

        event = process_day(
            self.path, "2000-01-03",
            closes(), forbidden)

        self.assertEqual(event["trades"], [])
