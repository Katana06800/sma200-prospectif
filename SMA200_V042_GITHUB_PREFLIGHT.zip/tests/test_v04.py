import unittest
from contextlib import closing
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import Mock
import test_guard as g
import prospective as p
from operations import require_anchor, repair_one, cycle
from state import connect, load, encode
from clock import Clock
from schedule import limits
from journal import history

class V04(unittest.TestCase):
    def setUp(self):
        t=TemporaryDirectory();self.addCleanup(t.cleanup)
        self.db=Path(t.name)/'paper.db';self.anchor=Path(t.name)/'anchor.json'
        protocol=Path(t.name)/'protocol';protocol.write_text('test only')
        p.init(self.db,g.DATE,protocol,clock_provider=lambda:Clock(g.START-1000000,0,100000000),now=self.now)
        self.anchor.write_text(encode(p.checkpoint(self.db)))
    def now(self):return 200000000
    def expired(self):return Clock(limits(g.DATE)[1]+1000,0,100000000)
    def open(self):return Clock(g.START+1000,0,100000000)
    def fetch(self,pair,day):return g.rows()[pair]
    def missed(self):
        return p.mark_expired(self.db,g.DATE,clock_provider=self.expired,now=self.now,fetch=Mock(side_effect=OSError('offline')))
    def repair(self):return repair_one(self.db,clock_provider=self.expired,now=self.now,fetch=self.fetch)
    def test_missing_anchor_blocks(self):
        self.anchor.unlink();t=Mock()
        with self.assertRaises(FileNotFoundError):cycle(self.db,self.anchor,tick=t)
        t.assert_not_called()
    def test_stale_anchor_blocks(self):
        self.missed();t=Mock()
        with self.assertRaisesRegex(ValueError,'ancre'):cycle(self.db,self.anchor,tick=t)
        t.assert_not_called()
    def test_truncated_journal_blocks(self):
        self.missed();self.anchor.write_text(encode(p.checkpoint(self.db)))
        with closing(connect(self.db)) as db,db:db.execute('DELETE FROM journal WHERE revision=1')
        with self.assertRaisesRegex(ValueError,'tronque'):require_anchor(self.db,self.anchor)
    def test_repair_append_only(self):
        self.missed();before=load(self.db);initial=p.checkpoint(self.db)
        with closing(connect(self.db)) as db:original=db.execute('SELECT * FROM journal').fetchall()
        result=self.repair();self.assertEqual(result['valuation']['equity_usdc'],'1000')
        self.assertEqual(load(self.db),before);self.assertIsNone(self.repair())
        with closing(connect(self.db)) as db:self.assertEqual(db.execute('SELECT * FROM journal').fetchall(),original)
        self.assertEqual(p.checkpoint(self.db,initial)['repair_count'],1)
    def test_repair_fails_without_data(self):
        self.missed()
        with self.assertRaises(OSError):repair_one(self.db,clock_provider=self.expired,now=self.now,fetch=Mock(side_effect=OSError('offline')))
        self.assertEqual(p.checkpoint(self.db)['repair_count'],0)
    def test_repair_future_rejected(self):
        self.missed()
        with self.assertRaisesRegex(ValueError,'future'):repair_one(self.db,clock_provider=self.open,now=self.now,fetch=self.fetch)
    def test_repair_corruption(self):
        self.missed();self.repair()
        with closing(connect(self.db)) as db,db:db.execute("UPDATE valuation_repairs SET valuation='{}'")
        with self.assertRaisesRegex(ValueError,'alteree'):p.checkpoint(self.db)
    def test_repair_deletion(self):
        self.missed();self.repair();anchor=p.checkpoint(self.db)
        with closing(connect(self.db)) as db,db:db.execute('DELETE FROM valuation_repairs')
        with self.assertRaisesRegex(ValueError,'tronquees'):p.checkpoint(self.db,anchor)
    def test_unexpected_error_fails_closed(self):
        result=cycle(self.db,self.anchor,tick=Mock(side_effect=RuntimeError('bug')))
        self.assertEqual(result['type'],'ERROR_REVIEW');self.assertEqual(history(self.db)[0][3],'INTERNAL_ERROR')
        with self.assertRaises(ValueError):require_anchor(self.db,self.anchor)
    def test_no_repair_during_decision(self):
        r=Mock();cycle(self.db,self.anchor,tick=Mock(return_value={'type':'PAPER_TEST'}),repair=r);r.assert_not_called()
    def test_wait_no_change_keeps_anchor(self):
        result=cycle(self.db,self.anchor,tick=Mock(return_value={'type':'WAIT'}),repair=Mock(return_value=None))
        self.assertEqual(result['type'],'WAIT');require_anchor(self.db,self.anchor)
