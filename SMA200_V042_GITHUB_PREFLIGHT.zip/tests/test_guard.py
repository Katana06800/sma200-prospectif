import unittest
from guard import check_closes, check_quotes, DAY
from clock import Clock
from schedule import limits
from execution import PAIRS
from decimal import Decimal as D

DATE = "2000-01-02"
START = limits(DATE)[0]
B, E = PAIRS

def rows():
    midnight = START - 900000
    return {
        p: [
            [str(midnight-i*DAY),
             "100","110","90","100",
             "1","1","1","1"]
            for i in range(200,0,-1)
        ] for p in PAIRS
    }

def quotes():
    return {
        B:(D("99"),D("101"),START+1400,550000000),
        E:(D("49"),D("51"),START+1400,600000000)
    }

class GuardTests(unittest.TestCase):

    def test_valid_closes(self):
        self.assertEqual(len(check_closes(DATE,rows())[B]),200)

    def test_wrong_day(self):
        with self.assertRaises(ValueError):
            check_closes("2000-01-03",rows())

    def test_missing_candle(self):
        r = rows()
        r[B].pop()
        with self.assertRaises(ValueError):
            check_closes(DATE,r)

    def test_unconfirmed_candle(self):
        r = rows()
        r[E][-1][8] = "0"
        with self.assertRaises(ValueError):
            check_closes(DATE,r)

    def test_valid_batch(self):
        c = Clock(START+1000,0,100000000)
        check_quotes(DATE,c,200000000,650000000,quotes())

    def test_closed_window(self):
        c = Clock(START+1000,0,100000000)
        with self.assertRaises(ValueError):
            check_quotes("2000-01-01",c,
                         200000000,650000000,quotes())

    def test_stale_at_execution(self):
        c = Clock(START+1000,0,100000000)
        with self.assertRaises(ValueError):
            check_quotes(DATE,c,
                         200000000,6000000000,quotes())

    def test_missing_pair(self):
        q = quotes()
        del q[E]
        c = Clock(START+1000,0,100000000)
        with self.assertRaises(ValueError):
            check_quotes(DATE,c,
                         200000000,650000000,q)
