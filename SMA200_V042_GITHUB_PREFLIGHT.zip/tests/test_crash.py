import unittest
import subprocess
import sys
from pathlib import Path
from tempfile import TemporaryDirectory
from state import initialize, load

CHILD = """
import sys
import os
from state import connect, encode, save

path, mode = sys.argv[1:3]
updated = {"cash":"500"}

if mode == "before":
    db = connect(path)
    db.execute("BEGIN IMMEDIATE")
    db.execute(
        "INSERT INTO journal VALUES (1,?,?,?)",
        ("2000-01-01", encode(updated),
         encode({"type":"TEST"}))
    )
    os._exit(77)

if mode == "after":
    save(path, 0, "2000-01-01",
         updated, {"type":"TEST"})
    os._exit(77)
"""

class CrashTests(unittest.TestCase):

    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name)/"test.db"
        initialize(self.path, {"cash":"1000"})

    def crash(self, mode):
        result = subprocess.run(
            [sys.executable, "-c", CHILD,
             str(self.path), mode],
            timeout=15
        )
        self.assertEqual(result.returncode, 77)

    def test_crash_before_commit(self):
        self.crash("before")
        self.assertEqual(
            load(self.path), (0, {"cash":"1000"})
        )

    def test_crash_after_commit(self):
        self.crash("after")
        self.assertEqual(
            load(self.path), (1, {"cash":"500"})
        )

if __name__ == "__main__":
    unittest.main()
