import unittest
from schedule import limits, window, closed_through

DAY = "2000-01-02"
S, E = limits(DAY)

class ScheduleTests(unittest.TestCase):

    def test_wait(self):
        self.assertEqual(window(DAY,S-100,S-1),"WAIT")

    def test_open(self):
        self.assertEqual(window(DAY,S,S+100),"OPEN")

    def test_expired(self):
        self.assertEqual(window(DAY,E,E+100),"EXPIRED")

    def test_uncertain(self):
        self.assertEqual(window(DAY,S-1,S),"UNCERTAIN")
        self.assertEqual(window(DAY,E-1,E),"UNCERTAIN")

    def test_invalid_clock(self):
        with self.assertRaises(ValueError):
            window(DAY,E,S)

    def test_previous_day_closed(self):
        self.assertEqual(closed_through(E-1),"2000-01-01")

    def test_current_day_closed(self):
        self.assertEqual(closed_through(E),"2000-01-02")
