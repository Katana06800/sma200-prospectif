import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from contextlib import closing
from unittest.mock import Mock
from clock import Clock
from schedule import limits
from prospective import init, tick, mark_expired, checkpoint
from state import load, connect
from journal import history
from recovery import mark_missed
import test_guard as g

class ProspectiveTests(unittest.TestCase):
    def setUp(self):
        tmp=TemporaryDirectory(); self.addCleanup(tmp.cleanup)
        self.db=Path(tmp.name)/'paper.db'
        self.protocol=Path(tmp.name)/'protocol.md'; self.protocol.write_text('test only')
        self.day=g.DATE
        self.clock=lambda:Clock(g.START-1000000,0,100000000)
        self.now=lambda:200000000
        init(self.db,self.day,self.protocol,clock_provider=self.clock,now=self.now)
    def open_clock(self): return Clock(g.START+1000,0,100000000)
    def expired_clock(self): return Clock(limits(self.day)[1]+1000,0,100000000)
    def fetch(self,p,day):
        r=g.rows()[p]
        if p==g.B:r[-1][4]='105'
        return r
    def execute(self):
        times=iter([200000000,200000000,250000000,650000000,700000000])
        return tick(self.db,clock_provider=self.open_clock,now=lambda:next(times),fetch=self.fetch,quotes=lambda c,d:g.quotes())
    def test_initial_future_required(self):
        with self.assertRaisesRegex(ValueError,'futur'):
            init(self.db.with_name('other.db'),self.day,self.protocol,clock_provider=self.open_clock,now=self.now)
    def test_no_overwrite(self):
        with self.assertRaises(FileExistsError):
            init(self.db,self.day,self.protocol,clock_provider=self.clock,now=self.now)
    def test_wait_no_market(self):
        fetch=Mock(side_effect=AssertionError)
        self.assertEqual(tick(self.db,clock_provider=self.clock,now=self.now,fetch=fetch)['type'],'WAIT')
        fetch.assert_not_called()
    def test_no_future_missed(self):
        with self.assertRaises(ValueError):
            mark_expired(self.db,self.day,clock_provider=self.open_clock,now=self.now,fetch=self.fetch)
        self.assertEqual(load(self.db)[0],0)
    def test_no_2099(self):
        with self.assertRaises(ValueError):
            mark_expired(self.db,'2099-01-01',clock_provider=self.expired_clock,now=self.now,fetch=self.fetch)
    def test_legacy_recovery_blocked(self):
        with self.assertRaises(ValueError):mark_missed(self.db,self.day,self.day)
    def test_first_day_missed(self):
        event=mark_expired(self.db,self.day,clock_provider=self.expired_clock,now=self.now,fetch=self.fetch)
        self.assertEqual(event['trades'],[]); self.assertEqual(event['valuation']['equity_usdc'],'1000')
        self.assertEqual(load(self.db)[1]['signals'],None)
        self.assertEqual(checkpoint(self.db)['revision'],1)
    def test_missing_prices_explicit(self):
        event=mark_expired(self.db,self.day,clock_provider=self.expired_clock,now=self.now,fetch=Mock(side_effect=OSError('offline')))
        self.assertIsNone(event['valuation']);self.assertIn('valuation_error',event)
        self.assertEqual(len(history(self.db)),1)
    def test_valid_trade_and_replay(self):
        initial=checkpoint(self.db);event=self.execute()
        self.assertEqual(event['valuation']['equity_usdc'],'1000')
        self.assertEqual(event['evidence']['final_ns'],700000000)
        self.assertEqual(len(event['trades']),1)
        self.assertEqual(checkpoint(self.db,initial)['revision'],1)
    def test_tamper_detected(self):
        self.execute(); expected=checkpoint(self.db)
        with closing(connect(self.db)) as db,db:
            db.execute("UPDATE journal SET event=replace(event,'1000','1001') WHERE revision=1")
        with self.assertRaises(ValueError):checkpoint(self.db,expected)
    def test_network_failure_no_trade(self):
        with self.assertRaises(OSError):
            tick(self.db,clock_provider=self.open_clock,now=self.now,fetch=Mock(side_effect=OSError('offline')))
        self.assertEqual(load(self.db)[0],0);self.assertEqual(history(self.db)[0][3],'NETWORK_ERROR')
    def test_external_checkpoint_incidents(self):
        self.test_network_failure_no_trade();expected=checkpoint(self.db)
        with closing(connect(self.db)) as db,db:db.execute('DELETE FROM incidents')
        with self.assertRaises(ValueError):checkpoint(self.db,expected)
