import unittest
import hashlib
import json
import test_runner as runner
from state import connect, load
from contextlib import closing

class EvidenceTests(unittest.TestCase):

    setUp = runner.RunnerTests.setUp
    run_day = runner.RunnerTests.run_day
    active_rows = runner.RunnerTests.active_rows

    def test_evidence_persisted(self):
        event = self.run_day(
            self.active_rows(),
            [200000000,250000000,
             650000000,700000000]
        )

        evidence = event["evidence"]

        raw = json.dumps(
            evidence["candles"],
            sort_keys=True,
            separators=(",",":")
        )

        self.assertEqual(
            evidence["candles_sha256"],
            hashlib.sha256(raw.encode()).hexdigest()
        )

        self.assertEqual(len(evidence["quotes"]),2)
        self.assertEqual(
            evidence["decision_ns"],250000000)

        with closing(connect(self.path)) as db:
            stored = db.execute(
                "SELECT event FROM journal "
                "WHERE revision=1"
            ).fetchone()

        self.assertEqual(json.loads(stored[0]),event)

    def test_no_evidence_on_rollback(self):
        before = load(self.path)

        with self.assertRaises(ValueError):
            self.run_day(
                self.active_rows(),
                [200000000,250000000,
                 650000000,6000000000]
            )

        self.assertEqual(load(self.path),before)

        with closing(connect(self.path)) as db:
            count = db.execute(
                "SELECT COUNT(*) FROM journal"
            ).fetchone()[0]

        self.assertEqual(count,1)
