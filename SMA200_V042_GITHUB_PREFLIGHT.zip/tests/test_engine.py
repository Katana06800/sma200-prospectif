import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from decimal import Decimal as D
from clock import Clock
from state import initialize, load
from journal import prepare, history
from main import process_day

B = "BTC-USDC"
E = "ETH-USDC"

def closes(b=True, e=False):
    return {
        B: [100]*199+[110 if b else 90],
        E: [100]*199+[110 if e else 90]
    }

def quotes(stale=False):
    clock = Clock(1000000, 0, 100000000)
    ts = 990000 if stale else 1000400
    return clock, 200000000, {
        B: (D("99"), D("101"), ts, 550000000),
        E: (D("49"), D("51"), ts, 600000000)
    }

def forbidden():
    raise AssertionError("Cotation inutile")

class EngineTests(unittest.TestCase):

    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name)/"test.db"

        initialize(self.path, {
            "cash": "1000",
            "positions": {B:"0", E:"0"},
            "signals": None,
            "last_day": None
        })
        prepare(self.path)

    def first(self):
        return process_day(
            self.path, "2000-01-01",
            closes(), quotes
        )

    def test_initial_purchase(self):
        event = self.first()
        rev, state = load(self.path)
        self.assertEqual(rev, 1)
        self.assertEqual(len(event["trades"]), 1)
        self.assertGreater(D(state["positions"][B]), 0)
        self.assertGreaterEqual(D(state["cash"]), 0)

    def test_no_unnecessary_trade(self):
        self.first()
        before = load(self.path)[1]
        event = process_day(
            self.path, "2000-01-02",
            closes(), forbidden
        )
        after = load(self.path)[1]
        self.assertEqual(event["trades"], [])
        self.assertEqual(before["cash"], after["cash"])
        self.assertEqual(
            before["positions"], after["positions"]
        )

    def test_signal_change(self):
        self.first()
        event = process_day(
            self.path, "2000-01-02",
            closes(False,True), quotes
        )
        sides = [t["side"] for t in event["trades"]]
        self.assertEqual(sides, ["SELL","BUY"])

    def test_duplicate(self):
        self.first()
        before = load(self.path)
        with self.assertRaises(ValueError):
            self.first()
        self.assertEqual(load(self.path), before)

    def test_stale_quote(self):
        before = load(self.path)
        with self.assertRaises(ValueError):
            process_day(
                self.path, "2000-01-01",
                closes(), lambda: quotes(True)
            )
        self.assertEqual(load(self.path), before)
        self.assertEqual(len(history(self.path)), 1)

    def test_retry_after_failure(self):
        with self.assertRaises(ValueError):
            process_day(
                self.path, "2000-01-01",
                closes(), lambda: quotes(True)
            )
        self.first()
        self.assertEqual(load(self.path)[0], 1)


    def test_individual_reception_valid(self):
        self.first()
        self.assertEqual(load(self.path)[0], 1)

    def test_individual_reception_invalid(self):
        clock, decision, q = quotes()
        q[B] = (*q[B][:3], 350000000)
        before = load(self.path)

        with self.assertRaises(ValueError):
            process_day(
                self.path, "2000-01-01", closes(),
                lambda: (clock, decision, q)
            )

        self.assertEqual(load(self.path), before)
        self.assertEqual(len(history(self.path)), 1)


    def test_missing_day(self):
        self.first()
        before = load(self.path)

        with self.assertRaisesRegex(
            ValueError, "JOURNEE MANQUEE"
        ):
            process_day(
                self.path, "2000-01-03",
                closes(False,True), forbidden
            )

        self.assertEqual(load(self.path), before)

if __name__ == "__main__":
    unittest.main()
