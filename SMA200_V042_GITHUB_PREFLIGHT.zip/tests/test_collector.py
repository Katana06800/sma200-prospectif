import unittest
from clock import Clock
from collector import collect_rows, collect_quotes
from market import PAIRS

class CollectorTests(unittest.TestCase):

    def setUp(self):
        self.clock = Clock(1000000,0,100000000)
        self.t = 200000000

    def now(self):
        return self.t

    def pause(self, seconds):
        self.t += int(seconds*1e9)

    def fresh(self, pair):
        self.t += 300000000
        ts = 1000000 + self.t//1000000 - 150
        return "99","101",ts

    def collect(self, fetch):
        return collect_quotes(
            self.clock, 200000000,
            fetch=fetch,
            now=self.now,
            pause=self.pause
        )

    def test_rows(self):
        self.assertEqual(
            collect_rows(lambda p: [p]),
            {p:[p] for p in PAIRS}
        )

    def test_valid_quotes(self):
        q = self.collect(self.fresh)
        self.assertEqual(set(q),set(PAIRS))

    def test_reject_old_then_accept(self):
        calls = []

        def fetch(pair):
            calls.append(pair)
            if len(calls) == 1:
                self.t += 300000000
                return "99","101",990000
            return self.fresh(pair)

        self.collect(fetch)
        self.assertEqual(calls.count(PAIRS[0]),2)

    def test_timeout(self):
        def stale(pair):
            self.t += 300000000
            return "99","101",990000

        with self.assertRaises(TimeoutError):
            self.collect(stale)

    def test_network_failure(self):
        def fail(pair):
            raise OSError("Connexion perdue")

        with self.assertRaises(OSError):
            self.collect(fail)

    def test_batch_expired(self):
        def slow(pair):
            if pair == PAIRS[1]:
                self.t += 5500000000
            return self.fresh(pair)

        with self.assertRaises(ValueError):
            self.collect(slow)
