import json
from datetime import datetime, timezone, date
from contextlib import closing
from state import connect

EVENTS = (
    "NETWORK_ERROR",
    "CLOCK_ERROR",
    "INVALID_DATA",
    "STALE_QUOTE",
    "TIMEOUT",
    "INTERNAL_ERROR",
    "RESTART"
)

def prepare(path):
    with closing(connect(path)) as db, db:
        db.execute("""CREATE TABLE IF NOT EXISTS incidents (
            id INTEGER PRIMARY KEY,
            observed_at_local_utc TEXT NOT NULL,
            day TEXT NOT NULL,
            kind TEXT NOT NULL,
            details TEXT NOT NULL
        )""")

def record(path, day, kind, details):
    if kind not in EVENTS:
        raise ValueError("Incident inconnu")

    if date.fromisoformat(day).isoformat() != day:
        raise ValueError("Date invalide")

    timestamp = datetime.now(timezone.utc).isoformat()
    payload = json.dumps(details, allow_nan=False)

    with closing(connect(path)) as db, db:
        db.execute(
            "INSERT INTO incidents "
            "(observed_at_local_utc,day,kind,details) "
            "VALUES (?,?,?,?)",
            (timestamp, day, kind, payload)
        )

def history(path):
    with closing(connect(path)) as db:
        return db.execute(
            "SELECT id,observed_at_local_utc,day,kind,details "
            "FROM incidents ORDER BY id"
        ).fetchall()
