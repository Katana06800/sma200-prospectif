"""Operational gate. No official run without an independently retained checkpoint."""
import argparse
from contextlib import closing
import json
import os
from pathlib import Path
import time
from urllib.error import URLError
import prospective as p
from state import connect, encode, load
from journal import record
from schedule import window


def repair_one(path, *, clock_provider=p.sync_clock, now=time.monotonic_ns, fetch=p.candles):
    """Append a missing mark, never change the original journal or holdings."""
    p.checkpoint(path)
    with closing(connect(path)) as db:
        rows = db.execute('SELECT revision,day,event FROM journal WHERE revision>0 ORDER BY revision').fetchall()
        repaired = {r[0] for r in db.execute('SELECT day FROM valuation_repairs')}
        for rev, day, raw in rows:
            event = json.loads(raw)
            if event['type'] == 'DECISION_MANQUEE' and event['valuation'] is None and day not in repaired:
                prev = json.loads(db.execute('SELECT state FROM journal WHERE revision=?',(rev-1,)).fetchone()[0])
                break
        else:
            return None
    proof = p.clock_evidence(clock_provider(),now())
    if window(day,proof['low_ms'],proof['high_ms']) != 'EXPIRED':
        raise ValueError('Reparation future interdite')
    rows = {pair:fetch(pair,day) for pair in p.PAIRS}
    mark = p.opening_mark(day,prev,p.check_closes(day,rows))
    with closing(connect(path)) as db, db:
        db.execute('INSERT INTO valuation_repairs VALUES (?,?,?,?)',(day,encode(proof),encode(rows),encode(mark)))
    return {'day':day,'valuation':mark}


def require_anchor(path, anchor):
    if Path(path).resolve() == Path(anchor).resolve():
        raise ValueError('Ancre distincte de la base requise')
    expected = json.loads(Path(anchor).read_text())
    current = p.checkpoint(path,expected)
    if current != expected:
        raise ValueError('Journal non entierement ancre: verifier et exporter un nouveau checkpoint avant reprise')
    return current


def cycle(path, anchor, *, tick=p.tick, repair=repair_one):
    # Exact match before every iteration, including WAIT and recovery.
    require_anchor(path,anchor)
    try:
        result = tick(path)
    except (URLError, OSError, ValueError, ArithmeticError, KeyError, IndexError, TypeError) as exc:
        # tick already logs expected errors. Fail closed until checkpoint reviewed.
        return {'type':'ERROR_REVIEW','error':str(exc),'class':type(exc).__name__}
    except Exception as exc:
        record(path,p.next_day(load(path)[1]),'INTERNAL_ERROR',{'stage':'supervisor','class':type(exc).__name__,'error':str(exc)})
        return {'type':'ERROR_REVIEW','error':str(exc),'class':type(exc).__name__}
    # Do not start a potentially slow repair when a decision is near or open.
    if result['type'] == 'WAIT':
        try:
            mark = repair(path)
            if mark is not None:
                return {'type':'VALUATION_REPAIRED',**mark}
        except Exception as exc:
            record(path,p.next_day(load(path)[1]),'INTERNAL_ERROR',{'stage':'valuation_repair','class':type(exc).__name__,'error':str(exc)})
            return {'type':'ERROR_REVIEW','error':str(exc),'class':type(exc).__name__}
    return result


def cli():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='cmd',required=True)
    q=sub.add_parser('init');q.add_argument('db');q.add_argument('day');q.add_argument('protocol')
    for cmd in ('once','run','audit','repair'):
        q=sub.add_parser(cmd);q.add_argument('db')
        q.add_argument('--expected',required=cmd in ('once','run','repair'))
    a=parser.parse_args()
    if a.cmd=='init': print(encode(p.init(a.db,a.day,a.protocol)));return
    if a.cmd=='audit':
        print(encode(p.checkpoint(a.db,json.loads(Path(a.expected).read_text()) if a.expected else None)));return
    if a.cmd=='repair':
        require_anchor(a.db,a.expected)
        print(encode(repair_one(a.db)));return
    while True:
        try:
            result=cycle(a.db,a.expected)
            print(encode(result),flush=True)
            # A changed journal must be externally reviewed and anchored before continuation.
            require_anchor(a.db,a.expected)
            if result['type']=='ERROR_REVIEW':return
        except Exception as exc:
            parser.exit(2,'ARRET DE SECURITE: '+str(exc)+'\n')
        if a.cmd=='once':return
        time.sleep(60)
