"""Diagnostic reseau uniquement: aucun portefeuille, ordre ou signal officiel."""
from datetime import timedelta
import time
from market import PAIRS, candles, sync_clock
from guard import check_closes
from collector import collect_quotes
from schedule import EPOCH


def main():
    clock = sync_clock()
    day = (EPOCH + timedelta(milliseconds=clock.server_ms)).date().isoformat()
    print('Date serveur UTC:', day, flush=True)
    print('Horloge OKX: OK', flush=True)
    rows = {p: candles(p, day) for p in PAIRS}
    validated = check_closes(day, rows)
    for p in PAIRS:
        print(p, ':', len(validated[p]), 'bougies UTC cloturees continues', flush=True)
    clock = sync_clock()
    quotes = collect_quotes(clock, time.monotonic_ns())
    for p in PAIRS:
        print(p, ': cotation fraiche bid/ask validee', flush=True)
    print('PREFLIGHT OKX: OK (lecture seule, hors experience officielle)', flush=True)


if __name__ == '__main__':
    main()
