import hashlib
import json
from guard import check_closes, check_quotes
from schedule import window
from main import process_day

def guarded_day(path, day, rows,
                clock_provider, quote_provider, now):

    closes = check_closes(day, rows)
    clock = clock_provider()
    batch = None
    raw = json.dumps(rows, sort_keys=True,
                     separators=(",",":"))
    evidence = {
        "schema": 1,
        "candles": json.loads(raw),
        "candles_sha256": hashlib.sha256(
            raw.encode()).hexdigest(),
        "clock": {
            "server_ms": clock.server_ms,
            "start_ns": clock.start_ns,
            "end_ns": clock.end_ns
        },
        "quotes": None
    }

    def check_window():
        if window(day, *clock.bounds(now())) != "OPEN":
            raise ValueError("Fenetre fermee")

    check_window()

    def provider():
        nonlocal batch
        decision = now()
        quotes = quote_provider(clock, decision)
        check_quotes(day, clock, decision, now(), quotes)
        batch = (decision, quotes)
        evidence["decision_ns"] = decision
        evidence["quotes"] = {
            p: {
                "bid": str(q[0]),
                "ask": str(q[1]),
                "timestamp_ms": q[2],
                "received_ns": q[3]
            } for p,q in quotes.items()
        }
        return clock, decision, quotes

    def before_save():
        final = now()

        if window(day, *clock.bounds(final)) != "OPEN":
            raise ValueError("Fenetre fermee")

        evidence["final_ns"] = final
        if batch is not None:
            decision, quotes = batch
            check_quotes(day, clock, decision, final, quotes)

    return process_day(
        path, day, closes, provider,
        before_save=before_save,
        evidence=evidence
    )
