import time
from decimal import Decimal
from market import PAIRS, candles, ticker

def collect_rows(fetch=candles):
    return {p: fetch(p) for p in PAIRS}

def collect_quotes(clock, decision, *,
                   fetch=ticker,
                   now=time.monotonic_ns,
                   pause=time.sleep):

    quotes = {}
    deadline = min(
        decision + 8_000_000_000,
        clock.end_ns + 10_000_000_000
    )

    for pair in PAIRS:
        while now() < deadline:
            bid, ask, ts = fetch(pair)
            received = now()

            bid = Decimal(str(bid))
            ask = Decimal(str(ask))

            if (
                received < deadline
                and bid.is_finite()
                and ask.is_finite()
                and 0 < bid <= ask
                and clock.accepts(
                    ts, decision, received
                )
            ):
                quotes[pair] = (
                    bid, ask, ts, received
                )
                break

            pause(0.2)

        else:
            raise TimeoutError("Cotation absente : " + pair)

    final = now()

    if final >= deadline:
        raise TimeoutError("Delai depasse")

    for p in PAIRS:
        if not clock.accepts(
            quotes[p][2], decision, final
        ):
            raise ValueError("Lot de cotations perime")

    return quotes
