from strategy import signal, targets, rebalance_required
from execution import rebalance, PAIRS
from state import load, save
from journal import record
from valuation import opening_mark

def process_day(path, day, closes, quote_provider, *, before_save=None, evidence=None):
    revision, state = load(path)

    previous_day = state["last_day"]
    if previous_day and day <= previous_day:
        raise ValueError("Decision deja traitee")

    from datetime import date, timedelta

    today = date.fromisoformat(day)

    if previous_day is None and state.get("prospective"):
        if day != state["prospective"]["start_day"]:
            raise ValueError("Date T0 incorrecte")
        if evidence is None:
            raise ValueError("Preuves obligatoires")

    if previous_day:
        expected = date.fromisoformat(previous_day) + timedelta(days=1)
        if today != expected:
            raise ValueError("JOURNEE MANQUEE")

    current = tuple(signal(closes[p])[0] for p in PAIRS)
    previous = state["signals"]

    if previous is not None:
        previous = tuple(previous)

    updated = dict(state)
    trades = []

    if rebalance_required(previous, current):
        clock, decision, quotes = quote_provider()

        for p in PAIRS:
            if not clock.accepts(
                quotes[p][2], decision, quotes[p][3]
            ):
                record(path, day, "STALE_QUOTE", {"pair": p})
                raise ValueError("Cotation refusee")

        cash, positions, trades = rebalance(
            state["cash"],
            state["positions"],
            quotes,
            targets(*current)
        )

        updated["cash"] = str(cash)
        updated["positions"] = {
            p: str(v) for p, v in positions.items()
        }

    updated["signals"] = list(current)
    updated["last_day"] = day

    event = {
        "type": "PAPER_TEST",
        "signals": list(current),
        "trades": [
            {k: str(v) for k, v in t.items()}
            for t in trades
        ]
    }

    if evidence is not None:
        event["evidence"] = evidence
        event["valuation"] = opening_mark(day, state, closes)
    elif state.get("prospective"):
        raise ValueError("Preuves obligatoires")

    save(path, revision, day, updated, event,
         before_commit=before_save)
    return event

if __name__ == "__main__":
    print("DEMARRAGE OFFICIEL VERROUILLE")
