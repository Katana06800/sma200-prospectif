from decimal import Decimal, localcontext

def signal(closes):
    if len(closes) != 200:
        raise ValueError("200 clotures requises")

    values = [Decimal(str(x)) for x in closes]

    if not all(x.is_finite() and x > 0 for x in values):
        raise ValueError("Cloture invalide")

    with localcontext() as ctx:
        ctx.prec = 50
        total = sum(values)
        sma = total / Decimal(200)
        active = values[-1] * 200 > total

    return active, sma

def targets(btc_active, eth_active):
    return {
        "BTC-USDC": Decimal("0.5") if btc_active else Decimal("0"),
        "ETH-USDC": Decimal("0.5") if eth_active else Decimal("0")
    }

def rebalance_required(previous, current):
    return previous is None or previous != current
