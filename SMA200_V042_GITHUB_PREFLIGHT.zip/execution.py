from decimal import Decimal as D, localcontext

PAIRS = ("BTC-USDC", "ETH-USDC")
COMMISSION = D("0.002")
SLIPPAGE = D("0.0005")
FEE = COMMISSION + SLIPPAGE
EPS = D("0.00000000000001")

def rebalance(cash, positions, quotes, weights):
    with localcontext() as ctx:
        ctx.prec = 50

        cash = D(str(cash))
        qty = {p: D(str(positions[p])) for p in PAIRS}
        w = {p: D(str(weights[p])) for p in PAIRS}
        bid = {p: D(str(quotes[p][0])) for p in PAIRS}
        ask = {p: D(str(quotes[p][1])) for p in PAIRS}

        if not cash.is_finite() or cash < 0:
            raise ValueError("Cash invalide")

        for p in PAIRS:
            if not all(x.is_finite() for x in
                       (qty[p], w[p], bid[p], ask[p])):
                raise ValueError("Valeur invalide")
            if not (qty[p] >= 0
                    and 0 < bid[p] <= ask[p]
                    and w[p] in (D("0"), D("0.5"))):
                raise ValueError("Parametre invalide")

        mid = {p: (bid[p]+ask[p])/2 for p in PAIRS}
        initial = cash + sum(qty[p]*mid[p] for p in PAIRS)

        def simulate(value):
            target = {p: w[p]*value/mid[p] for p in PAIRS}
            delta = {p: target[p]-qty[p] for p in PAIRS}
            balance = cash
            trades = []

            for p in sorted(PAIRS, key=lambda p: delta[p]):
                change = delta[p]
                if change == 0:
                    continue
                price = ask[p] if change > 0 else bid[p]
                notional = abs(change)*price
                fee = notional*FEE
                balance -= change*price + fee
                trades.append({
                    "pair": p,
                    "side": "BUY" if change > 0 else "SELL",
                    "quantity": abs(change),
                    "price": price,
                    "cost": fee
                })

            equity = balance + sum(
                target[p]*mid[p] for p in PAIRS
            )
            return balance, target, trades, equity

        low, high = D(0), initial

        for _ in range(256):
            if high-low <= EPS:
                break
            m = (low+high)/2
            if simulate(m)[3] >= m:
                low = m
            else:
                high = m

        if high-low > EPS:
            raise ValueError("Convergence insuffisante")

        balance, target, trades, equity = simulate(low)

        if balance < 0 or abs(equity-low) > D("1e-12"):
            raise ValueError("Comptabilite invalide")

        return balance, target, trades
