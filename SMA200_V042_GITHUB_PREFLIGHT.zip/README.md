# SMA200 prospectif V0.4.2 — CANDIDAT NON SCELLE

Paper trading exclusivement. Aucun ordre reel, aucune cle API. Ne pas initialiser une experience officielle avant validation independante, test de connectivite OKX et approbation d'un protocole prospectif distinct du protocole historique Binance.

## Verification locale

Python 3.9+ sous Linux/Termux. Publication atomique via renameat2(RENAME_NOREPLACE) de la libc, sans lien physique. Android 11+ expose cette fonction; compatibilite effective du noyau, du systeme de fichiers et de ctypes a verifier sur le telephone. En cas d'indisponibilite, arret sans publication ni ecrasement.

```sh
python -m unittest discover -s tests -v
```

Les 69 tests V0.3 sont conserves, 11 nouveaux tests de regression sont ajoutes (80 au total en V0.4). La V0.4.1 ajoutait 3 tests de compatibilite (83 au total). La V0.4.2 adapte le test de panne du mecanisme de publication et ajoute 5 tests (88 au total, tous reussis sous Linux). Les V0.4 et V0.4.1 ont echoue sur le telephone a cause des liens physiques; V0.4.2 reste a verifier sur Android. Les modules `strategy.py` et `execution.py` sont inchanges. Les fonctions historiques de bas niveau restent disponibles pour les tests; le point d'entree prospectif est `prospective.py`.

## Commandes futures (ne pas lancer init maintenant)

- `python prospective.py init paper.db AAAA-MM-JJ protocole_prospectif.md` : base neuve, T0 futur, 1000 USDC fictifs.
- `python prospective.py audit paper.db > checkpoint-init.json` : exporter le checkpoint initial et le conserver sur un support independant. Ne jamais ecraser une reference existante.
- `python prospective.py once paper.db --expected checkpoint-init.json` : iteration paper, aucune cle ni ordre reel. Une ancre exacte est obligatoire.
- `python prospective.py run paper.db --expected checkpoint-init.json` : boucle de surveillance; arret de securite apres une modification du journal, incident ou reparation si l'ancre n'a pas ete actualisee. Ce n'est pas encore un fonctionnement autonome sans supervision.
- `python prospective.py audit paper.db --expected checkpoint-init.json > checkpoint-suivant.json` : verifier le prefixe deja ancre et produire un nouveau checkpoint candidat. Examiner les nouveaux evenements et conserver le fichier independamment avant reprise avec `--expected checkpoint-suivant.json`.
- `python prospective.py repair paper.db --expected checkpoint-suivant.json` : documenter la premiere valorisation manquante avec des bougies historiques validees. Ne modifie ni les positions ni le journal initial. La table `valuation_repairs` conserve les preuves et est comprise dans les checkpoints. Une nouvelle ancre est necessaire apres cette operation.

L'ancre est un fichier de reference de confiance, non une signature ou un horodatage blockchain. Le programme ne peut pas verifier que le support est physiquement independant. Ne pas lancer plusieurs processus sur la meme base; les fonctions de bas niveau restent accessibles aux tests et ne constituent pas une interface officielle. Apres erreur inattendue, le superviseur tente de journaliser et s'arrete en securite; aucune reprise aveugle. Un stockage externe automatise, le controle independant de l'ancre et le redemarrage Android restent a concevoir.

## Conventions a approuver

Fenetre existante 00:15–02:00 UTC. Valorisation quotidienne AVANT decision, a 00:00 UTC, au dernier cours de cloture journalier avec les positions detenues avant le reequilibrage. Les frais de transaction restent comptabilises par le moteur. Une journee manquee conserve les positions et signaux precedents; valorisation historique si les bougies sont disponibles, sinon valeur nulle JSON (inconnue, pas zero USDC) et incident. Pas de reconstruction de transaction. Cette convention de valorisation n'est pas un rendement final a elle seule.

## Limites

Tests du moteur simules uniquement; les endpoints publics OKX ont repondu dans les essais curl du telephone (299 bougies cloturees continues par actif, tickers et heure serveur). Integration du moteur avec OKX, precision des cotations, execution longue duree sur Android, alertes externes et redemarrage autonome non verifies/non fournis. Le programme n'est pas un dispositif inviolable; les horloges sont des observations locales de l'API et non des preuves cryptographiques signees. Les controles temporels precedent la validation SQLite, pas une execution reelle sur le marche. Une migration des bases V0.1, V0.2 ou V0.3 n'est pas prise en charge. L'initialisation atomique requiert un repertoire local supportant renameat2 avec RENAME_NOREPLACE et fsync (utiliser le HOME Termux, pas le stockage partage Android). Les tests de crash couvrent un arret du processus, pas une panne materielle. Des dossiers temporaires .sma200-init-* peuvent subsister apres un arret brutal. Le journal est relu avant chaque decision ou recuperation; son cout sur plusieurs annees reste a mesurer. Les erreurs provoquent un arret de securite et une revue de l’ancre avant reprise. Une perte du support ou une impossibilite de journaliser peut imposer une intervention manuelle. La CLI impose un checkpoint exact mais ne garantit pas son independance. Le code est candidat a un nouvel audit avant scellement.

## Preflight GitHub Actions (manuel, hors experience)

Le workflow `.github/workflows/preflight.yml` tourne sur Ubuntu 24.04, limite a cinq minutes, permissions en lecture seule. Aucun declenchement automatique. Il lance les 88 tests puis `python3 preflight_okx.py`, qui utilise les modules de collecte et validation sans calculer de signal ni initialiser une base. Ce diagnostic peut etre execute a toute heure: il ne valide pas la fenetre officielle d'execution. Les erreurs reseau ou de fraicheur font echouer le job, sans assouplir les controles. Le reseau OKX depuis GitHub et la persistance entre jobs restent non verifies. Ne pas inclure de secrets ou de donnees personnelles dans le depot.
