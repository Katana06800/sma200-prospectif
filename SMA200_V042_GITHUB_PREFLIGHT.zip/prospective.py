"""V0.4: paper only. No official start without a future T0 and protocol file."""
import argparse
from contextlib import closing, contextmanager
from datetime import date, timedelta
import fcntl
import hashlib
import json
from pathlib import Path
import time
from urllib.error import URLError

from execution import PAIRS, rebalance
from strategy import signal, targets, rebalance_required
from clock import Clock
from decimal import Decimal
from state import initialize, load, save, connect, encode
from journal import prepare, record
from market import sync_clock, candles
from collector import collect_quotes
from schedule import limits, window, closed_through, EPOCH
from guard import check_closes, check_quotes
from runner import guarded_day
from valuation import opening_mark

VERSION = '0.4'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def source_hash():
    root = Path(__file__).resolve().parent
    return digest(encode({p.name: digest(p.read_bytes()) for p in sorted(root.glob('*.py'))}).encode())

def clock_evidence(c, ns):
    low, high = c.bounds(ns)
    return {'server_ms': c.server_ms, 'start_ns': c.start_ns,
            'end_ns': c.end_ns, 'observed_ns': ns, 'low_ms': low, 'high_ms': high}

def init(path, day, protocol, *, clock_provider=sync_clock, now=time.monotonic_ns):
    if date.fromisoformat(day).isoformat() != day:
        raise ValueError('Date ISO requise')
    proof = clock_evidence(clock_provider(), now())
    if proof['high_ms'] >= limits(day)[0]-900000:
        raise ValueError('T0 doit etre un jour UTC futur')
    raw = Path(protocol).read_bytes()
    if not raw.strip():
        raise ValueError('Protocole vide')
    cfg = {'version': VERSION, 'start_day': day, 'protocol_sha256': digest(raw),
           'source_sha256': source_hash(), 'init_clock': proof, 'venue': 'OKX EEA SPOT',
           'mode': 'PAPER_ONLY'}
    initialize(path, {'cash':'1000', 'positions':{p:'0' for p in PAIRS},
                      'signals':None, 'last_day':None, 'prospective':cfg})
    return cfg

def next_day(state):
    if state['last_day'] is None:
        return state['prospective']['start_day']
    return (date.fromisoformat(state['last_day'])+timedelta(days=1)).isoformat()

def check_config(state):
    cfg = state.get('prospective')
    if not cfg or cfg['source_sha256'] != source_hash():
        raise ValueError('Configuration absente ou code modifie')
    if cfg.get('version') != VERSION or cfg.get('venue') != 'OKX EEA SPOT' or cfg.get('mode') != 'PAPER_ONLY':
        raise ValueError('Configuration invalide')
    return cfg

def check_initial(state):
    cfg = check_config(state)
    if (state['cash'] != '1000' or state['positions'] != {p:'0' for p in PAIRS}
            or state['signals'] is not None or state['last_day'] is not None):
        raise ValueError('Etat initial invalide')
    proof = cfg['init_clock']
    c = Clock(proof['server_ms'], proof['start_ns'], proof['end_ns'])
    if (proof != clock_evidence(c,proof['observed_ns'])
            or proof['high_ms'] >= limits(cfg['start_day'])[0]-900000):
        raise ValueError('Preuve T0 invalide')
    return cfg

def mark_expired(path, day, *, clock_provider=sync_clock, now=time.monotonic_ns, fetch=candles):
    checkpoint(path)
    revision, state = load(path)
    check_config(state)
    if day != next_day(state):
        raise ValueError('Journee non consecutive')
    proof = clock_evidence(clock_provider(), now())
    if window(day, proof['low_ms'], proof['high_ms']) != 'EXPIRED':
        raise ValueError('Fenetre non expiree')
    # Historical prices can document valuation, never reconstruct a missed order.
    event = {'type':'DECISION_MANQUEE', 'signals':state['signals'], 'trades':[],
             'evidence':{'expiry_clock':proof}, 'valuation':None}
    try:
        rows = {p:fetch(p, day) for p in PAIRS}
        closes = check_closes(day, rows)
        event['valuation'] = opening_mark(day, state, closes)
        event['evidence']['historical_candles'] = rows
    except (OSError, ValueError, KeyError, IndexError, ArithmeticError) as exc:
        event['valuation_error'] = type(exc).__name__ + ': ' + str(exc)
        record(path, day, 'INVALID_DATA', {'stage':'missed_valuation', 'error':str(exc)})
    updated = dict(state, last_day=day)
    save(path, revision, day, updated, event)
    return event

@contextmanager
def exclusive(path):
    with open(str(Path(path).resolve())+'.lock', 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield

def tick(path, *, clock_provider=sync_clock, now=time.monotonic_ns, fetch=candles, quotes=collect_quotes):
    with exclusive(path):
        _, state = load(path)
        check_config(state)
        day = next_day(state)
        stage = 'clock'
        try:
            proof = clock_evidence(clock_provider(), now())
            status = window(day, proof['low_ms'], proof['high_ms'])
            if status == 'EXPIRED':
                stage = 'recovery'
                return mark_expired(path, day, clock_provider=clock_provider, now=now, fetch=fetch)
            if status != 'OPEN':
                return {'type':status, 'day':day}
            stage = 'audit'
            checkpoint(path)
            stage = 'candles'
            rows = {p:fetch(p, day) for p in PAIRS}
            stage = 'decision'
            return guarded_day(path, day, rows, clock_provider, quotes, now)
        except Exception as exc:
            kind = ('TIMEOUT' if isinstance(exc, TimeoutError) else
                    'NETWORK_ERROR' if isinstance(exc, (URLError, OSError)) else
                    'CLOCK_ERROR' if stage == 'clock' else
                    'INVALID_DATA' if isinstance(exc, (ValueError, KeyError, IndexError, ArithmeticError)) else 'INTERNAL_ERROR')
            record(path, day, kind, {'stage':stage, 'error':str(exc), 'class':type(exc).__name__})
            raise

def checkpoint(path, expected=None):
    """Hash journal prefix; trusted external copy required to detect rewrites."""
    with closing(connect(path)) as db:
        db.execute("BEGIN")
        if db.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
            raise ValueError('SQLite corrompu')
        rows = db.execute('SELECT revision,day,state,event FROM journal ORDER BY revision').fetchall()
        repairs = db.execute("SELECT day,observed,candles,valuation FROM valuation_repairs ORDER BY rowid").fetchall()
        incidents = db.execute('SELECT id,observed_at_local_utc,day,kind,details FROM incidents ORDER BY id').fetchall()
    if not rows:
        raise ValueError('Journal vide')
    h = '0'*64
    prev = None
    missing = {}
    for i,(rev,day,raw_state,raw_event) in enumerate(rows):
        state,event = json.loads(raw_state),json.loads(raw_event)
        if rev != i:
            raise ValueError('Revision manquante')
        if i == 0:
            if day is not None or event['type'] != 'INIT':
                raise ValueError('INIT invalide')
            cfg = check_initial(state)
        else:
            if day != next_day(prev) or state['last_day'] != day or state['prospective'] != cfg:
                raise ValueError('Calendrier ou configuration alteres')
            if event['type'] == 'DECISION_MANQUEE':
                if (event['trades'] or event['signals'] != prev['signals']
                        or any(state[k] != prev[k] for k in ('cash','positions','signals'))):
                    raise ValueError('Decision manquee alteree')
                proof = event['evidence']['expiry_clock']
                if proof != clock_evidence(Clock(proof['server_ms'], proof['start_ns'], proof['end_ns']), proof['observed_ns']):
                    raise ValueError('Horloge alteree')
                if window(day, proof['low_ms'], proof['high_ms']) != 'EXPIRED':
                    raise ValueError('Expiration invalide')
                if event['valuation'] is None:
                    missing[day] = prev
                if event['valuation'] is not None:
                    closes = check_closes(day, event['evidence']['historical_candles'])
                    if event['valuation'] != opening_mark(day,prev,closes):
                        raise ValueError('Valorisation alteree')
            elif event['type'] == 'PAPER_TEST':
                evidence = event['evidence']
                raw = json.dumps(evidence['candles'],sort_keys=True,separators=(',',':'))
                if digest(raw.encode()) != evidence['candles_sha256']:
                    raise ValueError('Bougies alterees')
                closes = check_closes(day,evidence['candles'])
                current = tuple(signal(closes[p])[0] for p in PAIRS)
                previous = None if prev['signals'] is None else tuple(prev['signals'])
                if state['signals'] != list(current) or event['signals'] != list(current):
                    raise ValueError('Signaux alteres')
                c = Clock(**evidence['clock'])
                final = evidence['final_ns']
                if window(day,*c.bounds(final)) != 'OPEN':
                    raise ValueError('Decision hors fenetre')
                if event['valuation'] != opening_mark(day,prev,closes):
                    raise ValueError('Valorisation alteree')
                if rebalance_required(previous,current):
                    q = {p:(Decimal(v['bid']),Decimal(v['ask']),v['timestamp_ms'],v['received_ns']) for p,v in evidence['quotes'].items()}
                    check_quotes(day,c,evidence['decision_ns'],final,q)
                    cash,pos,trades = rebalance(prev['cash'],prev['positions'],q,targets(*current))
                    if state['cash'] != str(cash) or state['positions'] != {p:str(v) for p,v in pos.items()} or event['trades'] != [{k:str(v) for k,v in t.items()} for t in trades]:
                        raise ValueError('Transactions alterees')
                elif event['trades'] or evidence['quotes'] is not None or any(state[k] != prev[k] for k in ('cash','positions')):
                    raise ValueError('Reequilibrage indu')
            else:
                raise ValueError('Type inconnu')
        h = digest(encode([h,rev,day,state,event]).encode())
        if expected is not None and rev == expected['revision'] and h != expected['sha256']:
            raise ValueError('Empreinte externe incompatible')
        prev = state
    if expected is not None and not 0 <= expected['revision'] <= rows[-1][0]:
        raise ValueError('Journal tronque')
    if expected is not None:
        n = expected['incident_count']
        if not 0 <= n <= len(incidents) or digest(encode(incidents[:n]).encode()) != expected['incidents_sha256']:
            raise ValueError('Incidents alteres ou tronques')
    for day, observed, raw_candles, raw_mark in repairs:
        if day not in missing:
            raise ValueError('Reparation sans valorisation manquante')
        proof = json.loads(observed)
        if proof != clock_evidence(Clock(proof['server_ms'],proof['start_ns'],proof['end_ns']),proof['observed_ns']) or window(day,proof['low_ms'],proof['high_ms']) != 'EXPIRED':
            raise ValueError('Horloge de reparation invalide')
        if json.loads(raw_mark) != opening_mark(day,missing[day],check_closes(day,json.loads(raw_candles))):
            raise ValueError('Valorisation reparee alteree')
    if expected is not None:
        n = expected['repair_count']
        if not 0 <= n <= len(repairs) or digest(encode(repairs[:n]).encode()) != expected['repairs_sha256']:
            raise ValueError('Reparations alterees ou tronquees')
    return {'repair_count':len(repairs),'repairs_sha256':digest(encode(repairs).encode()),'revision':rows[-1][0], 'sha256':h, 'incident_count':len(incidents),
            'incidents_sha256':digest(encode(incidents).encode())}

def cli():
    from operations import cli as operate
    operate()

if __name__ == '__main__': cli()
