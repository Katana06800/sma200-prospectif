from datetime import date, datetime, timedelta, timezone

EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)

def limits(day):
    d = date.fromisoformat(day)
    midnight = (d - EPOCH.date()).days * 86400000
    return midnight + 900000, midnight + 7200000

def window(day, low, high):
    if not 0 <= low <= high:
        raise ValueError("Horloge invalide")

    start, end = limits(day)

    if high < start:
        return "WAIT"
    if low >= end:
        return "EXPIRED"
    if start <= low and high < end:
        return "OPEN"

    return "UNCERTAIN"

def closed_through(low):
    if low < 0:
        raise ValueError("Horloge invalide")

    now = EPOCH + timedelta(milliseconds=low)
    day = now.date()

    if low < limits(day.isoformat())[1]:
        day -= timedelta(days=1)

    return day.isoformat()
