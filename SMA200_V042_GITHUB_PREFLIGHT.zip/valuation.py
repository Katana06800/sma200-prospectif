from decimal import Decimal, localcontext
from execution import PAIRS
from schedule import limits


def opening_mark(day, state, closes):
    """Value at 00:00 UTC, before the day's decision, using held quantities."""
    with localcontext() as ctx:
        ctx.prec = 50
        prices = {p: Decimal(str(closes[p][-1])) for p in PAIRS}
        equity = Decimal(state['cash']) + sum(
            Decimal(state['positions'][p]) * prices[p] for p in PAIRS)
        return {'asof_ms': limits(day)[0]-900000,
                'method': 'PRE_DECISION_UTC_CLOSE',
                'prices': {p: str(v) for p,v in prices.items()},
                'equity_usdc': str(equity)}
