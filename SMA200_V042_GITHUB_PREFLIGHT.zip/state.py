import json
import os
import ctypes
from tempfile import TemporaryDirectory
import sqlite3
from pathlib import Path
from contextlib import closing
from datetime import date

def encode(data):
    return json.dumps(data, sort_keys=True, allow_nan=False)

def connect(path):
    uri = Path(path).resolve().as_uri() + "?mode=rw"
    db = sqlite3.connect(uri, uri=True, timeout=5)
    db.execute("PRAGMA synchronous=FULL")
    return db

def publish_database(staging, path):
    # Linux/Android native atomic rename, explicitly refusing replacement.
    # No hard links, no subprocess, no unsafe rename fallback.
    libc = ctypes.CDLL(None, use_errno=True)
    try:
        rename = libc.renameat2
    except AttributeError as exc:
        raise OSError('renameat2 indisponible; publication refusee') from exc
    rename.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int,
                       ctypes.c_char_p, ctypes.c_uint]
    rename.restype = ctypes.c_int
    AT_FDCWD, RENAME_NOREPLACE = -100, 1
    if rename(AT_FDCWD, os.fsencode(staging), AT_FDCWD,
              os.fsencode(path), RENAME_NOREPLACE) != 0:
        err = ctypes.get_errno()
        raise OSError(err, os.strerror(err), str(path))

def initialize(path, state):
    path = Path(path)
    path = path.parent.resolve() / path.name
    if os.path.lexists(path):
        raise FileExistsError(path)
    # Build and commit privately; publish atomically without replacing a database.
    with TemporaryDirectory(prefix='.sma200-init-', dir=path.parent) as tmp:
        staging = Path(tmp)/'initial.db'
        with staging.open('xb'):
            pass
        with closing(connect(staging)) as db, db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("""CREATE TABLE journal (
                revision INTEGER PRIMARY KEY,
                day TEXT UNIQUE,
                state TEXT NOT NULL,
                event TEXT NOT NULL
            )""")
            db.execute("""CREATE TABLE incidents (
                id INTEGER PRIMARY KEY,
                observed_at_local_utc TEXT NOT NULL,
                day TEXT NOT NULL,
                kind TEXT NOT NULL,
                details TEXT NOT NULL
            )""")
            db.execute("""CREATE TABLE valuation_repairs (
                day TEXT PRIMARY KEY, observed TEXT NOT NULL, candles TEXT NOT NULL, valuation TEXT NOT NULL
            )""")
            db.execute("INSERT INTO journal VALUES (0,NULL,?,?)",
                       (encode(state), encode({"type":"INIT"})))
        with staging.open('rb') as f:
            os.fsync(f.fileno())
        publish_database(staging, path)
        fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)

def load(path):
    with closing(connect(path)) as db:
        row = db.execute(
            "SELECT revision,state FROM journal "
            "ORDER BY revision DESC LIMIT 1"
        ).fetchone()

        if row is None:
            raise ValueError("Etat absent")

        return row[0], json.loads(row[1])

def save(path, revision, day, state, event, *, before_commit=None):
    if date.fromisoformat(day).isoformat() != day:
        raise ValueError("Date invalide")

    with closing(connect(path)) as db, db:
        db.execute("BEGIN IMMEDIATE")
        last = db.execute(
            "SELECT revision,day FROM journal "
            "ORDER BY revision DESC LIMIT 1"
        ).fetchone()

        if last is None or last[0] != revision:
            raise ValueError("Etat obsolete ou absent")

        if last[1] is not None and day <= last[1]:
            raise ValueError("Decision deja traitee ou retroactive")

        db.execute(
            "INSERT INTO journal VALUES (?,?,?,?)",
            (revision+1, day, encode(state), encode(event))
        )

        if before_commit is not None:
            before_commit()
            db.execute("UPDATE journal SET event=? WHERE revision=?",
                       (encode(event), revision+1))

