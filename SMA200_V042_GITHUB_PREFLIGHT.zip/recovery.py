from datetime import date, timedelta
from state import load, save

def mark_missed(path, day, closed_through):
    missed = date.fromisoformat(day)
    expired = date.fromisoformat(closed_through)

    if missed > expired:
        raise ValueError("Fenetre non expiree")

    revision, state = load(path)
    if state.get("prospective"):
        raise ValueError("Utiliser la recuperation verifiee V0.2")
    previous = state["last_day"]

    if previous is None:
        raise ValueError("Calendrier T0 non initialise")

    expected = date.fromisoformat(previous) + timedelta(days=1)

    if missed != expected:
        raise ValueError("Journee non consecutive")

    updated = dict(state)
    updated["last_day"] = day

    event = {
        "type": "DECISION_MANQUEE",
        "signals": state["signals"],
        "trades": []
    }

    save(path, revision, day, updated, event)
    return event
