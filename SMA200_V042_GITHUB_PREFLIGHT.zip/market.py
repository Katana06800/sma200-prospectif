import json
import time
from decimal import Decimal
from urllib.request import Request, urlopen
from urllib.parse import urlencode
from clock import Clock

BASE = "https://eea.okx.com/api/v5/"
PAIRS = ("BTC-USDC", "ETH-USDC")
DAY = 86400000

def get(path, **params):
    url = BASE + path
    if params:
        url += "?" + urlencode(params)

    req = Request(url, headers={
        "Accept": "application/json",
        "User-Agent": "V28.3-Paper-ReadOnly/1.0"
    })

    with urlopen(req, timeout=3) as r:
        data = json.load(r)

    if not isinstance(data, dict) or not isinstance(data.get("code"), str):
        raise ValueError("Enveloppe API invalide")
    if data["code"] != "0":
        raise ValueError(str(data.get("msg", "Erreur API")))
    if not isinstance(data.get("data"), list):
        raise ValueError("Donnees API invalides")
    return data["data"]

def server_time():
    rows = get("public/time")
    if (len(rows) != 1 or not isinstance(rows[0], dict)
            or not isinstance(rows[0].get("ts"), str)
            or not rows[0]["ts"].isascii() or not rows[0]["ts"].isdigit()):
        raise ValueError("Horloge API invalide")
    return int(rows[0]["ts"])

def sync_clock():
    start = time.monotonic_ns()
    server = server_time()
    end = time.monotonic_ns()
    return Clock(server, start, end)

def candles(pair, day=None):
    if pair not in PAIRS:
        raise ValueError("Paire interdite")

    server = server_time()
    expected = (server // DAY - 1) * DAY
    if day is not None:
        from schedule import limits
        requested = limits(day)[0] - 900000 - DAY
        if requested > expected:
            raise ValueError("Cloture future")
        expected = requested
    rows = {}
    params = {
        "instId": pair,
        "bar": "1Dutc",
        "limit": 100
    }

    if day is not None:
        params["after"] = expected + DAY

    for _ in range(3):
        page = get("market/history-candles", **params)

        if not page:
            break

        for c in page:
            if (not isinstance(c, list) or len(c) != 9
                    or not all(isinstance(x, str) for x in c)
                    or c[8] not in ("0", "1")):
                raise ValueError("Format invalide")

            if c[8] != "1":
                continue

            ts = int(c[0])
            o, h, l, close = map(Decimal, c[1:5])
            volumes = list(map(Decimal, c[5:8]))

            if not (
                all(x.is_finite() for x in
                    [o, h, l, close] + volumes)
                and 0 < l <= min(o, close)
                and max(o, close) <= h
                and all(v >= 0 for v in volumes)
                and ts <= expected
                and ts % DAY == 0
            ):
                raise ValueError("Bougie invalide")

            if ts in rows and rows[ts] != c:
                raise ValueError("Doublon incoherent")

            rows[ts] = c

        params["after"] = min(int(c[0]) for c in page)

        if len(rows) >= 200:
            break

        time.sleep(0.3)

    dates = sorted(rows)[-200:]

    if dates != [
        expected-i*DAY for i in range(199, -1, -1)
    ]:
        raise ValueError("Serie UTC incomplete")

    return [rows[t] for t in dates]

def ticker(pair):
    if pair not in PAIRS:
        raise ValueError("Paire interdite")

    rows = get("market/ticker", instId=pair)
    if (len(rows) != 1 or not isinstance(rows[0], dict)
            or not all(isinstance(rows[0].get(k), str)
                       for k in ("bidPx", "askPx", "instId", "ts"))):
        raise ValueError("Cotation API malformee")
    d = rows[0]
    bid = Decimal(d["bidPx"])
    ask = Decimal(d["askPx"])

    if not (
        d["instId"] == pair
        and bid.is_finite()
        and ask.is_finite()
        and 0 < bid <= ask
        and int(d["ts"]) > 0
    ):
        raise ValueError("Cotation invalide")

    return bid, ask, int(d["ts"])
