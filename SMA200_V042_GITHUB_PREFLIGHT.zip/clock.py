from dataclasses import dataclass

@dataclass(frozen=True)
class Clock:
    server_ms: int
    start_ns: int
    end_ns: int

    def __post_init__(self):
        if not (
            0 < self.server_ms
            and 0 <= self.end_ns-self.start_ns <= 1_000_000_000
        ):
            raise ValueError("Synchronisation incertaine")

    def bounds(self, now_ns):
        if not 0 <= now_ns-self.end_ns <= 10_000_000_000:
            raise ValueError("Reference temporelle expiree")
        low = self.server_ms + (now_ns-self.end_ns)//1_000_000 - 1
        high = self.server_ms + (now_ns-self.start_ns+999_999)//1_000_000 + 1
        return low, high

    def accepts(self, quote_ms, decision_ns, received_ns):
        if not self.end_ns <= decision_ns <= received_ns:
            return False
        try:
            _, decision_high = self.bounds(decision_ns)
            low, high = self.bounds(received_ns)
        except ValueError:
            return False
        return (
            quote_ms > decision_high
            and 0 <= low-quote_ms <= high-quote_ms <= 5000
        )
